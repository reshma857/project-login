﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;

namespace newpro
{
    public partial class register : System.Web.UI.Page
    {
       static string constr = ConfigurationManager.ConnectionStrings["connStr"].ConnectionString;

        protected void Page_Load(object sender, EventArgs e)
        {

        }
        protected void Button1_Click(object sender, EventArgs e)
        {
            
                SqlConnection con = new SqlConnection(constr);
                try
                {
                    string base64Decoded = Text_password.Value;
                    string base64Encoded;
                    byte[] data = System.Text.ASCIIEncoding.ASCII.GetBytes(base64Decoded);
                    base64Encoded = System.Convert.ToBase64String(data);


                    //string base64Encoded = "YmFzZTY0IGVuY29kZWQgc3RyaW5n";
                    //string base64Decoded;
                    //byte[] data = System.Convert.FromBase64String(base64Encoded);
                    //base64Decoded = System.Text.ASCIIEncoding.ASCII.GetString(data);


                    SqlCommand com = new SqlCommand("StoreReg", con);
                    com.CommandType = CommandType.StoredProcedure;
                    SqlParameter p1 = new SqlParameter("@username", Text_username.Value);
                    SqlParameter p2 = new SqlParameter("@email", Text_email.Value);
                    SqlParameter p3 = new SqlParameter("@Password1", base64Encoded);
                    SqlParameter p4 = new SqlParameter("@phone_no", Text_phone.Value);
                    com.Parameters.Add(p1);
                    com.Parameters.Add(p2);
                    com.Parameters.Add(p3);
                    com.Parameters.Add(p4);
                    if (con.State != ConnectionState.Open)
                        con.Open();
                    int returnvalue = com.ExecuteNonQuery();
                    Text_username.Value = "";
                    Text_email.Value = "";
                    Text_password.Value = "";
                    Text_phone.Value = "";
                    Label1.Text = "Registration successfull";
                    Response.Redirect("login.aspx", false);
                    }

                catch (Exception ex)
                {
                    Label1.Text = "your email or phone number is already registered...!!";

                }
                finally
                {
                    con.Close();
                }


            
        }
    }
}

       