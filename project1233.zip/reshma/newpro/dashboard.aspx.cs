﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;

namespace newpro
{
    public partial class dashboard : System.Web.UI.Page
    {

        static string constr = ConfigurationManager.ConnectionStrings["connStr"].ConnectionString;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (!string.IsNullOrEmpty(Session["Username"] as string))
                {
                   Response.Cache.SetNoStore();
                 }
               else
               {
                   Response.Redirect("login.aspx");
               }
            }
        
        }
             
        
        protected void Button1_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(constr);
            try
            {




                SqlCommand cmd = new SqlCommand("person_val", con);
                cmd.CommandType = CommandType.StoredProcedure;

               

                SqlParameter p1 = new SqlParameter("@first_name", First_Name.Value);
                SqlParameter p2 = new SqlParameter("@last_name", Last_Name.Value);
                SqlParameter p3 = new SqlParameter("@emp_id", emp_id.Value);
                SqlParameter p4 = new SqlParameter("@gender", gender.Value);
                SqlParameter p5 = new SqlParameter("@blood_group", Blood_Group.Value);
              
                cmd.Parameters.Add(p1);
                cmd.Parameters.Add(p2);
                cmd.Parameters.Add(p3);
                cmd.Parameters.Add(p4);
                cmd.Parameters.Add(p5);

                if (con.State != ConnectionState.Open)
                    con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                GridView1.DataSource = dr;

                GridView1.DataBind();

                    lblmsg1.Text = "   ";
            }
            catch (Exception ex)
            {
                lblmsg1.Text = "Details are already Submitted";    
            }

            finally
            {
                con.Close();
            }
       
        }
        protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            string constr = ConfigurationManager.ConnectionStrings["connStr"].ConnectionString;
            SqlConnection con = new SqlConnection(constr);
            SqlCommand com = new SqlCommand("person_del", con);
            com.CommandType = CommandType.StoredProcedure;
            SqlParameter p3 = new SqlParameter("@emp_id", emp_id.Value);
            com.Parameters.Add(p3);
            com.Connection = con;
            con.Open();
            com.ExecuteNonQuery();
            SqlDataReader dr = com.ExecuteReader();
            if (dr.HasRows)
            {
                lblmsg1.Text = "not deleted";

            }
            else
            {

                GridView1.DataSource = dr;
                GridView1.DataBind();
                lblmsg1.Text = "deleted successfully";
            }

            con.Close();  
            
        }

        protected void GridView1_RowEditing(object sender, GridViewEditEventArgs e)
        {
            GridView1.EditIndex = e.NewEditIndex;
            GridView1.DataBind();
        }

        protected void LinkButton1_Click(object sender, EventArgs e)
{

//    Session.Clear();
//    Session.Abandon();
    Response.Redirect("logout.aspx");
   
}



    }

}