﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;

namespace newpro
{
    public partial class login : System.Web.UI.Page
    {
        static string constr = ConfigurationManager.ConnectionStrings["connStr"].ConnectionString;
        protected void Page_Load(object sender, EventArgs e)
        {

        }


        protected void Button2_Click(object sender, EventArgs e)

        {
           

            SqlConnection con = new SqlConnection(constr);
            try
            {
                string base64Decoded = txt_Password.Value;
                string base64Encoded;
                byte[] data = System.Text.ASCIIEncoding.ASCII.GetBytes(base64Decoded);
                base64Encoded = System.Convert.ToBase64String(data);

                SqlCommand com = new SqlCommand("Storelg", con);
                com.CommandType = CommandType.StoredProcedure;

                SqlParameter P1 = new SqlParameter("@username",Txt_Username.Value);
                SqlParameter P2 = new SqlParameter("@email", txt_email.Value);
                SqlParameter P3 = new SqlParameter("@Password1",base64Encoded);

                com.Parameters.Add(P1);
                com.Parameters.Add(P2);
                com.Parameters.Add(P3);

                if(con.State != ConnectionState.Open)
                    con.Open();
                int returnvalue = com.ExecuteNonQuery();

                 SqlDataAdapter da = new SqlDataAdapter(com);

                DataTable dt = new DataTable();
               
                da.Fill(dt);


                if (dt.Rows.Count > 0)
                    {
                        Session["Username"] = Txt_Username.Value;
                        Response.Redirect("dashboard.aspx", false);

                    }
                    else
                    {
                        Label1.Visible = true;

                        Label1.Text = " Invalid Username  or email or Password !!";
                    }
                }
               
            
            
                catch(Exception ex)
                    {
                        Label1.Visible = true;
                        Label1.Text = " Invalid Username  or Password  or email !!";
                    }
                

            finally
            {
               con.Close();
            }




        }
    }
}